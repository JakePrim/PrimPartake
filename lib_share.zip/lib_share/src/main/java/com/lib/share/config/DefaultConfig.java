package com.lib.share.config;

/**
 * @author prim
 * @version 1.0.0
 * @desc
 * @time 2018/7/5 - 下午2:46
 */
public class DefaultConfig {
    public static final String REDIRECT_URL = "";
}
