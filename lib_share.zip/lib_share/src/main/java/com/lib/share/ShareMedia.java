package com.lib.share;

/**
 * @author prim
 * @version 1.0.0
 * @desc share media
 * @time 2018/7/5 - 上午11:27
 */
public enum ShareMedia {
    SINA,
    QZONE,
    QQ,
    WEIXIN,
    WEIXIN_CIRCLE,
    COPY,
    MORE
}
